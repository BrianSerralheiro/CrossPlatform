﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManagerTitle : MonoBehaviour
{
    // Creates a class variable to keep track of SoundManager instance
    // - Ensures only ONE instance will ever exist
    // - defaulted to private access
    static SoundManagerTitle _instance = null;

    // Used to play AudioClips 
    public AudioSource sfxSource;
    public AudioSource musicSource;

    // Use this for initialization
    void Start()
    {
        // Check if SoundManager instance already exists in Scene
        if (instance)
        {
            // SoundManager exists, delete copy
            DestroyImmediate(gameObject);
        }
        else
        {
            // Assign SoundManager to variable '_instance'
            instance = this;

            // Stop the sound
            sfxSource.Stop();
        }
    }

    public void playSound(AudioClip clip, float volume = 1.0f)
    {

        //Assign volume to AudioSource volume
        sfxSource.volume = volume;

        // Tell AudioSource what clip to play
        sfxSource.clip = clip;

        // Tell AudioSource to play sound
        sfxSource.Play();

    }

    // Provides access to private '_instance'
    // - Variable must be declared above
    // - Variable must be static because method is static
    public static SoundManagerTitle instance
    {
        get { return _instance; }   // can also use just get;
        set { _instance = value; }  // can also use just set;
    }
}
