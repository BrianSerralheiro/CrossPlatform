﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooter : MonoBehaviour
{
    public Transform projectileSpawnPoint;
    public GameObject projectile;
    public float projectileForce;

    // Used for handling projectile mechanic
    public float projectileFireRate;
    float timeSinceLastFire = 0.0f;

    // Used for handling health mechanic
    public bool isFacingLeft;

    public Transform player;
    public Transform eShooter;
    private bool isDead = false;

    Rigidbody2D rb;

    //Handles health
    public int health;

    // Used to change size of Healthbar size
    public RectTransform healthBar;

    // Use this for initialization
    void Start()
    {
        player = GameObject.Find("Megaman").transform;
        eShooter = GameObject.Find("EnemyShooter").transform;
        rb = GetComponent<Rigidbody2D>();

        // Checks if ProjectileSpawnPoint GameObject is connected
        if (!projectileSpawnPoint)
        {
            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.LogError("No Projectile SpawnPoint found on GameObject");
        }

        // Checks if Projectile GameObject is connected
        if (!projectile)
        {
            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.LogError("No Projectile found on GameObject");
        }

        // Check if projectileForce was set to something not 0
        if (projectileForce <= 0)
        {
            // Assign a default value if one is not set in the Inspector
            projectileForce = 7.0f;

            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.Log("Projectile Force was not set. Defaulting to " + projectileForce);
        }

        // Check if projectileFireRate was set to something not 0
        if (projectileFireRate <= 0)
        {
            // Assign a default value if one is not set in the Inspector
            projectileFireRate = 2.0f;

            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.Log("Projectile Fire Rate was not set. Defaulting to " + projectileFireRate);
        }
    }

    // Update is called once per frame
    void Update()   
    {
        
            // Check if enough time has passed before firing another projectile
            if (Time.time > timeSinceLastFire + projectileFireRate)
            {
                // Fire a projectile
                fire();

                // Timestamp at last time Projectile was fired
                timeSinceLastFire = Time.time;
            }
        if (isDead == false)
        {
            if (player.position.x > rb.position.x && !isFacingLeft || player.position.x < rb.position.x && isFacingLeft)
            {
                flip();
            }

            //Healthbar calculation
            healthBar.sizeDelta = new Vector2(health * 0.06f, healthBar.sizeDelta.y);

            if (health <= 0)
            {
                Destroy(gameObject);
                isDead = true;
                Debug.Log("isDead: " + isDead);
            }
        }
    }

    void flip()
    {

        // Method 1: Toggle isFacingLeft variable
        isFacingLeft = !isFacingLeft;

        // Method 2: Toggle isFacingLeft variable
        /*if (isFacingLeft)
            isFacingLeft = false;
        else
            isFacingLeft = true;
        */

        // Make a copy of old scale value
        Vector3 scaleFactor = transform.localScale;

        // Flip scale of 'x' variable
        scaleFactor.x *= -1; // scaleFactor.x = -scaleFactor.x;

        // Update scale to new flipped value
        transform.localScale = scaleFactor;
    }

    // Fire projectile function
    void fire()
    {
        // Create Projectile and add to Scene
        // - Thig to create (projectile gameObejct from Project Panel)
        // - Location to spawn (projectileSpawnPoint)
        // - Rotation of spawned gameObject (projectileSpawnPoint)
        Projectile_Enemy p = Instantiate(projectile, projectileSpawnPoint.position,
            projectileSpawnPoint.rotation).GetComponent<Projectile_Enemy>();

        // Apply movement speed to Projectile
        p.speed = -projectileForce;

        // Change tag dynamically
        // - Must exist in tag list to function
        p.tag = "Projectile";

        // Change Color dynamically
        //p.GetComponent<SpriteRenderer>().color = new Color32(0,0,255,125);

        p.GetComponent<SpriteRenderer>().color = new Color(0.0F, 0.0F, 1.0F, 0.5F);
    }

}


