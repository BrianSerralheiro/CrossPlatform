﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    /*
    public static GameManager gm;
    private static int _remainingLives = 3;
    public static int RemainingLives
    {
        get { return _remainingLives; }
    }
    */

    // Creates a class variable to keep track of GameManager instance
    // - Ensures only ONE instance will ever exist
    // - defaulted to private access
    static GameManager _instance = null;

    // Used to instantiate Player GameObject;
    public GameObject playerPrefab;

    // Use this for initialization
    void Start()
    {

        // Check if GameManager instance already exists in Scene
        if (instance)
        {
            // GameManager exists, delete copy
            DestroyImmediate(gameObject);
        }
        else
        {
            // Assign GameManager to variable '_instance'
            instance = this;

            // Do not destroy GameObject Script is attached to
            DontDestroyOnLoad(this);
        }

        // Assign 0 value to variable;
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (SceneManager.GetActiveScene().name == "VGP123A1_Serralheiro_Brian")
                SceneManager.LoadScene("GameOver");
            else if
                (SceneManager.GetActiveScene().name == "TitleScreen")
                SceneManager.LoadScene("VGP123A1_Serralheiro_Brian");

        }

    }
    // Gets called to Start game
    public void StartGame()
    {
        SceneManager.LoadScene("VGP123A1_Serralheiro_Brian");
    }
    // Gets called to Quit game
    public void QuitGame()
    {
        Debug.Log("Quit Game.");
        Application.Quit();
    }

    public void OptionsMenu()
    {
        SceneManager.LoadScene("Credits");
    }

    public void backtoTitle()
    {
        SceneManager.LoadScene("TitleScreen");
    }


    // Called to Spawn player
    public void spawnPlayer(int spawnLocation)
    //public void spawnPlayer(Transform spawnLocation)
    //public void spawnPlayer(Vector3 spawnLocation)
    //public void spawnPlayer(GameObject spawnLocation)
    {
        // Spawn point must be named (SceneName)_(number), ie. Level1_0
        string spawnPointName = SceneManager.GetActiveScene().name
            + "_" + spawnLocation;

        // Find where Player should be spawned
        Transform spawnPointTransform =
            GameObject.Find(spawnPointName).GetComponent<Transform>();

        // Instantiate (Create) Player(Character) GameObject
        Instantiate(playerPrefab, spawnPointTransform.position,
            spawnPointTransform.rotation);
    }

    // Provides access to private '_instance'
    // - Variable must be declared above
    // - Variable must be static because method is static
    public static GameManager instance
    {
        get { return _instance; }   // can also use just get;
        set { _instance = value; }  // can also use just set;
    }

    // Declare variable 'score' and create get/set function for it
    public int score
    {
        get; set;
    }



    public void EndGame()
    {
        Debug.Log("GameOver");
    }

    /* public void KillPlayer (Character player)

     {
         Destroy (player.gameObject);
         _remainingLives -= 1;
         if (_remainingLives <=0)
         {
             gm.EndGame();
         }
         else
         {
             gm.StartCoroutine(gm._RespawnPlayer()); 
         }


     }
     */
}
