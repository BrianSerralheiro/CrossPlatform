﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealthBar : MonoBehaviour
{

        //Holds starting health of 'Obstacle'

        public int health;

        // Used to change size of Healthbar size
        public RectTransform healthBar;
        public float healthScale;

        // Use this for initialization
        void Start()
        {

            if (health <= 0)
            {
                health = 5;

                Debug.Log("Health was not set. Defaulting to " + health);

            }

            healthScale = healthBar.sizeDelta.x / health;


        }

        private void OnCollisionEnter2D(Collision2D c)
        {
            if (c.gameObject.tag == "Projectile")
            {
                health--;

                //health-= c.gameObject.GetComponent<Projectile>().GetDamage();

                healthBar.sizeDelta = new Vector2(health * healthScale, healthBar.sizeDelta.y);

                //Check if 'Obstacle' is dead
                if (health <= 0)
                {
                    /*Play Sound
                     * Create Partle Effect
                     * Trigger a Respawn
                     * Play an Animation
                     * Etc..
                     */

                    //'Enemy' is dead, delete from Scene
                    Destroy(gameObject);
                }
            }
        }
    }
