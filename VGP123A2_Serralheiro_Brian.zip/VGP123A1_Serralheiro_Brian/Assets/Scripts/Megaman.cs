﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Megaman : MonoBehaviour
{


    Rigidbody2D rb;

    public Rigidbody2D rb2;

    public float speed;

    //Handles health
    public int health;

    public float jumpForce;

    public bool isGrounded;
    public LayerMask isGroundLayer;
    public Transform groundCheck;
    public float groundCheckRadius;
    public float Attackvalue;

    // Handle Projectile Instantiation (aka Creation)
    public Transform projectileSpawnPoint;
    public Projectile projectilePrefab;
    public float projectileForce;



    public GameObject spawnPoint;
    public GameObject megaman;



    Animator anim;



    //Handles character flipping
    public bool isFacingRight;


    //Audio
    public AudioClip jumpSFX;
    public AudioClip shootSFX;


    public AudioSource audioSource;

    // Use this for initialization
    void Start()
    {

        anim = GetComponent<Animator>();

        rb = GetComponent<Rigidbody2D>();

        if (!rb)
        {
            Debug.LogWarning("No Rigidbody2D Found.");
        }

        if (!rb2)
        {
            rb2 = GetComponent<Rigidbody2D>();
        }

        if (speed <= 0)
        {
            speed = 2.0f;

            Debug.LogWarning("Default speeding to " + speed);


        }

        if (jumpForce <= 0)
        {
            jumpForce = 1.5f;

            Debug.LogWarning("DefaultjumpForce" + jumpForce);

        }

        if (groundCheckRadius <= 0)
        {
            groundCheckRadius = 0.2f;

            Debug.LogWarning("Ground checkRadius" + groundCheckRadius);

        }


        // Checks if projectileSpawnPoint GameObject is connected
        if (!projectilePrefab)
        {
            Debug.LogError("No projectilePrefab found on GameObject");
        }

        // Check if speed was set to something not 0
        if (projectileForce == 0)
        {
            // Assign a default value if one is not set in the Inspector
            projectileForce = 7.0f;

            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.Log("Projectile Force was not set. Defaulting to " + projectileForce);
        }


        audioSource = GetComponent<AudioSource>();
        if (!audioSource)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.playOnAwake = false;
            audioSource.loop = false;
            audioSource.volume = 1.0f;
        }



    }
    /*
void direction()
    {
        spawnPoint = GameObject.FindWithTag("SpawnPoint");
        megaman = GameObject.FindWithTag("Player");

        Debug.Log("Mega: " + megaman.transform.position.x);
        Debug.Log("Spawn: " + spawnPoint.transform.position.x);

        if (spawnPoint.transform.position.x > megaman.transform.position.x && projectileForce < 0)
        {
            projectileForce *= -1;
            Debug.Log("Vel: + " + projectileForce);
        }
        if (spawnPoint.transform.position.x < megaman.transform.position.x && projectileForce > 0)
        {
            projectileForce *= -1;
            Debug.Log("Vel: - " + projectileForce);
        }
    }
    */

    // Update is called once per frame
    void Update()
    {

       // direction();

        if (!groundCheck)
        {
            Debug.LogWarning("No groundCheck found.");
        }



        if (!anim)
        {
            Debug.LogWarning("No Animator Found.");
        }

        if (!projectileSpawnPoint)
        {
            Debug.LogError("No projectilePrefab found on GameObject");

        }

        isGrounded = Physics2D.OverlapCircle(groundCheck.position,
            groundCheckRadius, isGroundLayer);
        


        float moveValue = Input.GetAxisRaw("Horizontal");

        if (Input.GetButtonDown("Jump") && isGrounded)

        {
            rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

            anim.SetFloat("jumpForce", Mathf.Abs(jumpForce));

        }
        /*
        if (isGrounded = true)
        {
            anim.SetBool("grounded" = true);
        }

        if (isGrounded = false)
        {
            anim.SetBool("grounded" = false);
        }
        */

        anim.SetFloat("MoveValue", Mathf.Abs(moveValue));


        if (isFacingRight && moveValue < 0)
            flip();

        else if (!isFacingRight && moveValue > 0)
            flip();

        // - Configuration can be changed later
        if (Input.GetButtonDown("Fire1"))
        {
            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.Log("Pew pew");

            // Call function to play sound
            playSound(shootSFX);

            // Tells Animator to transition to another Clip
            // - Parameter 'Attack' must be created in Animator window
            anim.SetTrigger("Attack");

            // Create Projectile and add to Scene
            // - Thig to create (projectile gameObejct from Project Panel)
            // - Location to spawn (projectileSpawnPoint)
            // - Rotation of spawned gameObject (projectileSpawnPoint)

            /*Projectile temp = Instantiate(projectile,
                projectileSpawnPoint.position,
                projectileSpawnPoint.rotation) as Projectile;
              */

            /*temp.GetComponent<Rigidbody2D>().velocity = 
                new Vector2( projectileForce, 0);
            */

            /*temp.GetComponent<Rigidbody2D>().velocity = 
                Vector2.right * projectileForce;
            */

            //temp.GetComponent<Projectile>().speed = projectileForce;
            /*
            if (!isFacingLeft)
                // Apply movement speed to projectile that is spawned
                temp.speed = projectileForce;
            else
                temp.speed = -projectileForce;
                */

        }

        if (health <= 0)
        {
            // Assign a default value if one is not set in the Inspector
            SceneManager.LoadScene("GameOver");
            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.Log("Health was not set. Defaulting to " + health);
        }

        // Check if Left Control was pressed
        // - Tied to key and cannot be changed
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            // Prints a message to Console (Shortcut: Control+Shift+C)
            Debug.Log("Pew pew");
            playSound(shootSFX);
        }


        
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            Debug.Log("Pew Pew");
            playSound(shootSFX);

            // Call function to make pew pew
            fire();
        }
        anim.SetBool("grounded", isGrounded);
        rb.velocity = new Vector2(speed * moveValue, rb.velocity.y);



}

    void fire()
    {
        // Creates Projectitle and add it's to the scene
        // - projectilePrefab is the thing to create
        // - projectileSpawnPoint is where and what rotation to use when created
       Projectile temp =
            Instantiate(projectilePrefab, projectileSpawnPoint.position, projectileSpawnPoint.rotation);

        /*
        temp.GetComponent<Rigidbody2D>().velocity =
            new Vector2(projectileForce, 0);

        temp.GetComponent<Rigidbody2D>().velocity =
            Vector2.right * projectileForce;

        */

        //temp.speed = projectileForce;


    }
    
    void flip()
    {
        isFacingRight = !isFacingRight;
        /*
         if (isFacingRight)
            isFacingRight = false;
         else
            isFacingRight = true;
        */

        Vector3 scaleFactor = transform.localScale;

        scaleFactor.x *= -1; // scaleFactor.x = -scaleFactor.x;                       Same thing.

        transform.localScale = scaleFactor;


    }

    void OnCollisionEnter2D(Collision2D collision)

    {
        if (collision.gameObject.name == "HPItem")
        {
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.name == "ManaItem")
        {
            Destroy(collision.gameObject);
        }


        if (collision.gameObject.name == "1UPItem")
        {
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.name == "1UPItem2")
        {
            Destroy(collision.gameObject);
        }
    }

    // Function used to set clip to play through AudioSource attached to Character
    void playSound(AudioClip clip, float volume = 1.0f)
    {
        //Assign volume to AudioSource volume
        audioSource.volume = volume;

        // Tell AudioSource what clip to play
        audioSource.clip = clip;

        // Tell AudioSource to play sound
        audioSource.Play();
    }



}

