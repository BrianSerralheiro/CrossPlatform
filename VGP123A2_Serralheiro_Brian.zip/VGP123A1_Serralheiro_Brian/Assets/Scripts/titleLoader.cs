﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class titleLoader : MonoBehaviour
{

    static titleLoader _instance = null;


    // Use this for initialization
    void Start()
    {

        // Check if GameManager instance already exists in Scene
        if (instance)
        {
            // GameManager exists, delete copy
            DestroyImmediate(gameObject);
        }
        else
        {
            // Assign GameManager to variable '_instance'
            instance = this;

            // Do not destroy GameObject Script is attached to
            DontDestroyOnLoad(this);
        }

        // Assign 0 value to variable;
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (SceneManager.GetActiveScene().name == "TitleScreen")
                SceneManager.LoadScene("GameOver");
            else if
                (SceneManager.GetActiveScene().name == "GameOver")
                SceneManager.LoadScene("TitleScreen");
            else if
                (SceneManager.GetActiveScene().name == "VGP123A1_Serralheiro_Brian")
                SceneManager.LoadScene("GameOver");
        }

    }

    public static titleLoader instance
    {
        get { return _instance; }   // can also use just get;
        set { _instance = value; }  // can also use just set;
    }

    // Declare variable 'score' and create get/set function for it
    public int score
    {
        get; set;
    }
}
