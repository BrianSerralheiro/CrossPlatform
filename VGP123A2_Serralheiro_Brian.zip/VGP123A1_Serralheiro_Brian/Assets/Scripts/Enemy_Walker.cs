﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Automatically adds Components when Script is added to GameObject
[RequireComponent(typeof(Rigidbody2D))]     // Rigidbody2D is added if not already added
public class Enemy_Walker : MonoBehaviour
{

    // How fast enemy moves
    public float speed;
    // How enemy moves 
    Rigidbody2D rb;

    // Handles flipping Character
    public bool isFacingLeft;
    public int health;



    // Use this for initialization
    void Start()
    {

        // Check if speed was set to something not 0
        if (speed <= 0)
            speed = 0.9f;

        // Reference Component through script
        rb = GetComponent<Rigidbody2D>();

        // Checks if Component exists
        if (!rb)
        {
            // Add a Component if it doesnt already exist
            rb = gameObject.AddComponent<Rigidbody2D>();
        }

    }

    // Update is called once per frame
    void Update()
    {

        // Check is Enemy is facing left
        if (isFacingLeft)
            // Move Enemy left
            rb.velocity = new Vector2(-speed, rb.velocity.y);
        else
            // Move Enemy right
            rb.velocity = new Vector2(speed, rb.velocity.y);

        if (health <= 0)
        {

            Destroy(gameObject);
        }

    }



    // Checks for Collisions
    // - At least one GameObject involved in Collision must have a Rigidbody2D attached
    // - Only works for Colliders set to "Is Trigger"
    private void OnTriggerEnter2D(Collider2D c)
    {
        // Check if Enemy hit a barrier
        if (c.gameObject.tag == "EnemyBarrier")
        {
            // Flip Enemy
            flip();
        }
    }

    // Function that will flip Character look left or right
    void flip()
    {
        // Toggle isFacingLeft variable
        isFacingLeft = !isFacingLeft;

        // Make a copy of old scale value
        Vector3 scaleFactor = transform.localScale;

        // Flip scale of 'x' variable
        scaleFactor.x *= -1; // scaleFactor.x = -scaleFactor.x;

        // Update scale to new flipped value
        transform.localScale = scaleFactor;

    }

}
